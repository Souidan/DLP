﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client;
using System.IO;

namespace ReportingAPISample.src.Violations
{
    public class IncidentViolations : ServiceCall
    {
        /**
     * Checks if the incident violations are requested as per the arguments passed.
     * 
     * @param arguments
     *            map with INCIDENT_ID & MATCH_HIGHLIGHTS
     * 
     * @return True if arguments contain INCIDENT_ID & MATCH_HIGHLIGHTS is true
     */
        public override Boolean isRequested(Dictionary<String, String> arguments)
        {
            return (getArgument(arguments, "INCIDENT_ID") != null && getArgument(arguments, "VIOLATIONS") != null && getArgument(arguments, "VIOLATIONS").ToLower().Equals("true"));
        }

        /**
     * Submits incident violation request for the specified incident and gets
     * the incident violation response.
     * 
     * @param client
     *            incident reporting web service client
     * @param arguments
     *            map with INCIDENT_ID
     */

        public override void submit(ReportingServiceClient client,
                                    Dictionary<String, String> arguments)
        {
            IncidentViolationsRequest incidentViolationsRequest = new IncidentViolationsRequest();

            List<long> incidentIds = new List<long>();
            foreach (String key in arguments.Keys)
            {
                if (key.StartsWith("INCIDENT_ID"))
                {
                    long incidentId = Convert.ToInt64(getArgument(arguments, key));
                    incidentIds.Add(incidentId);
                }
            }
            incidentViolationsRequest.incidentLongId = incidentIds.ToArray();
            incidentViolationsRequest.includeImageViolations = isTrue(arguments, "GET_IMAGE_VIOLATIONS");
            incidentViolationsRequest1 request = new incidentViolationsRequest1(incidentViolationsRequest);

            try
            {
                IncidentServicePortType clientPort = client.getPortClient();
                incidentViolationsResponse IncidentViolationsResponse = clientPort.incidentViolations(request);

                for (int i = 0; i < IncidentViolationsResponse.incidentViolationsResponse1.Length; i++)
                {
                    IncidentViolation incidentViolation = IncidentViolationsResponse.incidentViolationsResponse1[i];
                    Console.WriteLine("---------------------------------------------------------------------------");
                    Console.WriteLine("Incident Violations for the incident id: " + incidentViolation.incidentLongId);
                    Console.WriteLine("---------------------------------------------------------------------------");
                    Console.WriteLine("The response status code is: " + incidentViolation.statusCode);
                    printViolatingComponents(incidentViolation.violatingComponent);
                }



            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
                Console.WriteLine(exp.StackTrace.ToString());

            }
        }


        private void printViolatingComponents(ViolatingComponent[] violatingComponents)
        {
            foreach (ViolatingComponent vComponent in violatingComponents)
            {
                Console.WriteLine();
                Console.WriteLine("Component Name:" + vComponent.name);
                Console.WriteLine("Component Type:" +
                               vComponent.violatingComponentType.Value);
                if (vComponent.documentFormat != null)
                {
                    Console.WriteLine("Document Format:" + vComponent.documentFormat);
                }
                Console.WriteLine("Violation Count:" + vComponent.violationCount);
                printViolationSegments(vComponent.violatingSegment);

                if (vComponent.violatingImageInformation != null)
                {
                    foreach (ImageViolationType imageViolation in vComponent.violatingImageInformation)
                    {
                        Console.WriteLine("Confidence:"+ imageViolation.confidence);
                        Console.WriteLine("Filling Score:"+ imageViolation.fillScore);
                        Console.WriteLine("Profile:"+ imageViolation.profileName);
                    }
                }


            }

        }

        private void printViolationSegments(ViolatingSegment[] violatingSegments)
        {
            if (violatingSegments != null)
            {
                foreach (ViolatingSegment vSegment in violatingSegments)
                {
                    Console.WriteLine();
                    object[] obj = vSegment.Items;
                    foreach (object ob in obj)
                    {
                        if (ob.GetType() == typeof(ViolatingSegmentDocumentViolation))
                        {
                            ViolatingSegmentDocumentViolation documentViolation = (ViolatingSegmentDocumentViolation)ob;
                            printDocumentViolation(documentViolation);

                        }

                        else if (ob.GetType() == typeof(ViolatingSegmentFileSizeViolation))
                        {
                            ViolatingSegmentFileSizeViolation fileSizeViolation = (ViolatingSegmentFileSizeViolation)ob;
                            printFileSizeViolation(fileSizeViolation);
                        }
                        else
                        {
                            ViolatingSegmentText text = (ViolatingSegmentText)ob;
                            printViolatingText(text);
                        }

                    }
                }
            }


        }

        private void printDocumentViolation(ViolatingSegmentDocumentViolation documentViolation)
        {
            Console.WriteLine("Document Violation:");
            Console.WriteLine("Profile Name:" + documentViolation.documentProfileName);
            Console.WriteLine("Document Path:" + documentViolation.documentPath);
            if (documentViolation.Item.GetType() == typeof(string))
            {
                Console.WriteLine("Match Percentage(%):" + documentViolation.Item);
            }
        }

        private void printFileSizeViolation(ViolatingSegmentFileSizeViolation fileSizeViolation)
        {
            Console.WriteLine("File Size Violation: " + fileSizeViolation.violatingFileSize + " " + fileSizeViolation.units);

        }
        private void printViolatingText(ViolatingSegmentText text)
        {
            if (textType.Violation.Equals(text.type))
            {
                Console.WriteLine("Violating Text: " + text.Value);
            }
            else
            {
                Console.WriteLine("Non Violating Text: " + text.Value);
            }
        }


    }
}
