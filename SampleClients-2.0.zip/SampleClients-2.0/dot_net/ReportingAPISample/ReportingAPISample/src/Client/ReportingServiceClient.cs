﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Description;
using Authentication;

namespace Client
{
    public class ReportingServiceClient
    {
        private string url;
        private string username;
        private string password;
        IncidentServicePortTypeClient client = null;

        public ReportingServiceClient(string url, string username, string password)
        {
            // Bypass SSL certificate properties
            // validation
            //
            ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(validateRemoteCertificate);
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            this.url = url;
            this.username = username;
            this.password = password;
        }


        public void connect()
        {
            // Prepare HTTP bindings with username/password
            // basic authentication. Init incident reporting
            // service port
            //
            // An Example of the URL is as follows
            //this.url = "https://<EnforceMachineHostName/IP>/ProtectManager/services/incidents";

            EndpointAddress epAddress = new EndpointAddress(this.url);

            BasicHttpBinding basicAuthBindings = setupBasicAuthentication();
            client = new IncidentServicePortTypeClient(basicAuthBindings, epAddress);

            client.ClientCredentials.UserName.UserName = this.username;
            client.ClientCredentials.UserName.Password = this.password;

            IEndpointBehavior behavior = new HttpBasicAuthenticationEndpointBehavior();
            client.Endpoint.Behaviors.Add(behavior);

            // connect to the reporting API service
            // 
            client.Open();
        }


        /// 
        /// <summary>
        /// Eliminates SSL certificate parameters verification. This method
        /// could be implemented to adjust SSL certificate verification
        /// </summary>
        /// 
        /// <param name="sender"></param>
        /// <param name="certificate"></param>
        /// <param name="chain"></param>
        /// <param name="policyErrors"></param>
        /// 
        /// <returns></returns>
        /// 
        public static bool validateRemoteCertificate(object sender,
                                                      X509Certificate certificate,
                                                      X509Chain chain,
                                                      SslPolicyErrors policyErrors)
        {
            return true;
        }


        /// <summary>
        /// Setup Basic HTTP authentication via
        /// service endpoint bindings
        /// </summary>
        /// 
        private static BasicHttpBinding setupBasicAuthentication()
        {
            // HTTP bindings for Basic authentication
            //
            BasicHttpBinding httpBinding = new BasicHttpBinding();

            httpBinding.Security.Mode = BasicHttpSecurityMode.Transport;
            httpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            httpBinding.MessageEncoding = WSMessageEncoding.Mtom;
            httpBinding.ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max;
            httpBinding.TextEncoding = System.Text.Encoding.UTF8;
            httpBinding.TransferMode = TransferMode.Buffered;//.StreamedResponse;
            httpBinding.AllowCookies = false;
            httpBinding.MaxBufferPoolSize = 524288;
            httpBinding.MaxBufferSize = 1048576000;
            httpBinding.MaxReceivedMessageSize = 1048576000;    // 100 Mb
            httpBinding.OpenTimeout = TimeSpan.FromMilliseconds(60000);
            httpBinding.CloseTimeout = TimeSpan.FromMilliseconds(60000);
            httpBinding.SendTimeout = TimeSpan.FromMilliseconds(60000);
            httpBinding.ReceiveTimeout = TimeSpan.FromMilliseconds(600000);
            httpBinding.HostNameComparisonMode = HostNameComparisonMode.StrongWildcard;
            httpBinding.AllowCookies = false;
            httpBinding.UseDefaultWebProxy = false;
            httpBinding.BypassProxyOnLocal = true;

            return httpBinding;
        }

        /// 
        /// <summary>
        /// Get web service port client
        /// </summary>
        /// <returns>web service port client</returns>
        /// 
        public IncidentServicePortTypeClient getPortClient()
        {
            if (client == null)
            {
                throw (new Exception("Port client not connected to reporting API web service"));
            }

            return client;
        }

        /// 
        /// <summary>
        /// Disconnect from web service
        /// </summary>
        /// 
        public void disconnect()
        {
            try
            {
                // Disconnect to reporting API web service
                //
                Console.WriteLine();
                if (client.State.Equals(CommunicationState.Opened))
                {
                    client.Close();
                }
                client = null;
            }
            catch (Exception exp)
            {
                throw (exp);
            }
        }
    }
}
