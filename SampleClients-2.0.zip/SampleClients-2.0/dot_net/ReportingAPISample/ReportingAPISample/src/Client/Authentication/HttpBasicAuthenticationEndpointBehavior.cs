﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System.ServiceModel.Description;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using System;
using Authentication;

/// 
/// <summary>
/// Basic authentication client runtime behavior. Find username
/// and password in HTTP binding credentials property
/// </summary>
/// 
namespace Authentication
{
    public class HttpBasicAuthenticationEndpointBehavior : IEndpointBehavior
    {
        private string _username;
        private string _password;

        /// 
        /// <summary>
        /// Constructor, no parameters accepted. Will find username and password
        /// in HTTP binding credential property
        /// </summary>
        /// 
        public HttpBasicAuthenticationEndpointBehavior()
        {
            this._username = "undefined";
            this._password = "undefined";
        }

        /// 
        /// <summary>
        /// Set HTTP binding parameters. Find authentication username
        /// and password in binding credentials property
        /// </summary>
        /// 
        /// <param name="endpoint"></param>
        /// <param name="bindingParameters"></param>
        /// 
        public void AddBindingParameters(ServiceEndpoint endpoint,
                                         BindingParameterCollection bindingParameters)
        {
            foreach (object param in bindingParameters)
            {
                foreach (object property in bindingParameters)
                {
                    if (property.GetType() == typeof(ClientCredentials))
                    {
                        ClientCredentials credentials = property as ClientCredentials;
                        this._username = credentials.UserName.UserName;
                        this._password = credentials.UserName.Password;
                    }
                }
            }
        }

        /// 
        /// <summary>
        /// Add <code>HttpBasicAuthenticationMessageInspector</code> message inspector
        /// that will take care to create and append basic authentication HTTP header
        /// </summary>
        /// 
        /// <param name="endpoint"></param>
        /// <param name="clientRuntime"></param>
        /// 
        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {
            HttpBasicAuthenticationMessageInspector inspector = new HttpBasicAuthenticationMessageInspector(this._username, this._password);
            clientRuntime.MessageInspectors.Add(inspector);
        }

        /// 
        /// <summary>
        /// Do not supply any dispatching behavior
        /// </summary>
        /// 
        /// <param name="endpoint"></param>
        /// <param name="endpointDispatcher"></param>
        /// 
        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
        }

        /// 
        /// <summary>
        /// Do not implement any validations
        /// </summary>
        /// 
        /// <param name="endpoint"></param>
        /// 
        public void Validate(ServiceEndpoint endpoint)
        {
        }
    }
}