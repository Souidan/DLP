﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;
using System.ServiceModel;
using System.Net;
using System;
using System.Text;

/// 
/// <summary>
/// Add basic authentication HTTP header. Acceept username
/// and password in constructor parameters
/// </summary>
///
namespace Authentication
{
    public class HttpBasicAuthenticationMessageInspector : IClientMessageInspector
    {
        private const string BASIC_AUTH_HTTP_HEADER = "Authorization";
        private string _username;
        private string _password;

        /// 
        /// <summary>
        /// Basic authentication message inspector
        /// constructor
        /// </summary>
        /// <param name="username">user name string</param>
        /// <param name="password">password string</param>
        /// 
        public HttpBasicAuthenticationMessageInspector(string username, string password)
        {
            this._username = username;
            this._password = password;
        }

        /// 
        /// <summary>
        /// Do not handle after HTTP request event
        /// </summary>
        /// <param name="reply"></param>
        /// <param name="correlationState"></param>
        /// 
        public void AfterReceiveReply(ref Message reply, object correlationState)
        {
            reply.Properties.Remove(HttpResponseMessageProperty.Name);
        }

        /// 
        /// <summary>
        /// Add basic authentication HTTP header on request
        /// beginning event
        /// </summary>
        /// 
        /// <param name="request"></param>
        /// <param name="channel"></param>
        /// <returns></returns>
        /// 
        public object BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            HttpRequestMessageProperty httpRequestMessage;
            object httpRequestMessageObject;
            byte[] credentialBuffer = new UTF8Encoding().GetBytes(this._username + ":" + this._password);
            string headerValue = "Basic " + Convert.ToBase64String(credentialBuffer);

            if (request.Properties.TryGetValue(HttpRequestMessageProperty.Name, out httpRequestMessageObject))
            {
                httpRequestMessage = httpRequestMessageObject as HttpRequestMessageProperty;
                httpRequestMessage.Headers[BASIC_AUTH_HTTP_HEADER] = headerValue;
            }
            else
            {
                httpRequestMessage = new HttpRequestMessageProperty();
                httpRequestMessage.Headers.Add(BASIC_AUTH_HTTP_HEADER, headerValue);
                request.Properties.Add(HttpRequestMessageProperty.Name, httpRequestMessage);
            }
            return null;
        }
    }
}