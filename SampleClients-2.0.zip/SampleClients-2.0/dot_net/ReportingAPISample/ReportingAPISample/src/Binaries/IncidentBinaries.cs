﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client;
using System.IO;

namespace ReportingAPISample.src.List
{
    public class IncidentBinaries : ServiceCall
    {
        /// 
        /// <summary>
        /// Check if Enforce report incident binaries 
        /// is requested
        /// 
        /// Support arguments:
        /// 
        /// INCIDENT_ID=...            - incident id
        /// GET_ALL_COMPONENTS=True    - to retrieve binaries for all incident attachments, optional
        /// GET_ORIGINAL_MESSAGE=True  - to retrieve incident original message binary, optional
        /// COMPONENT_ID=...           - incident attachment ID, applicable when GET_ALL_COMPONENTS=False or skipped
        /// 
        /// </summary>
        /// <param name="arguments">arguments(INCIDENT_ID)</param>
        /// <returns>True if arguments contain INCIDENT_ID</returns>
        /// 
        public override Boolean isRequested(Dictionary<String, String> arguments)
        {
            return (getArgument(arguments, "INCIDENT_ID") != null &&
                   ((getArgument(arguments, "GET_ALL_COMPONENTS") != null) ||
                    (getArgument(arguments, "GET_ORIGINAL_MESSAGE") != null) ||
                    (getArgument(arguments, "COMPONENT_ID") != null)));
        }


        /// 
        /// <summary>
        /// Retrieve binary attachment and/or main message 
        /// for specified incident ID.
        /// 
        /// </summary>
        /// <param name="client">incident reporting web service client</param>
        /// <param name="arguments">arguments(INCIDENT_ID)</param>
        /// 
        public override void submit(ReportingServiceClient client,
                                    Dictionary<String, String> arguments)
        {
            // Create web service request.
            // Specify incident ID to download binaries
            //
            IncidentBinariesRequest request = new IncidentBinariesRequest();
            String incidentId = getArgument(arguments, "INCIDENT_ID");
     
            request.incidentLongId = Convert.ToInt64(incidentId);
            request.incidentLongIdSpecified = true;

            // Request incident all binary components
            // original message
            //
            request.includeAllComponents = isTrue(arguments, "GET_ALL_COMPONENTS");
            request.includeOriginalMessage = isTrue(arguments, "GET_ORIGINAL_MESSAGE");

            // Get incident individual components binary
            // content. Optional feature. Returns binary
            // for specified component only
            //
            String componentId = getArgument(arguments, "COMPONENT_ID");
            if (componentId != null)
            {
                request.componentLongId = Convert.ToInt64(componentId);
                request.componentLongIdSpecified = true;
            }

            // Submit web service request. 
            // Read incident binaries
            //
            IncidentServicePortTypeClient clientPort = client.getPortClient();
            IncidentBinariesResponse response = clientPort.incidentBinaries(request);

            // Save incident original message 
            // content
            //
            String fileName;
            if (request.includeOriginalMessage)
            {
                fileName = saveFile(response.incidentLongId, "original_message", response.originalMessage);
                Console.WriteLine("Saved original message to: " + fileName);
            }

            if (response.Component != null)
            {
                // Save incident binary attachments
                //
                foreach (IncidentBinariesResponseComponent component in response.Component)
                {
                    fileName = saveFile(response.incidentLongId, component.name, component.content);

                    Console.WriteLine("Binary component name: " + component.name);
                    Console.WriteLine("Binary component id: " + component.componentLongId);
                    Console.WriteLine("Binary component type: " + component.componentType);
                    Console.WriteLine("Saved binary content to: " + fileName);
                }
            }
        }


        /// 
        /// <summary>
        /// Save incident binary content to local file.
        /// Include incident ID to file name
        /// </summary>
        /// <param name="incidentId">incident ID</param>
        /// <param name="fileName">incident content file name</param>
        /// <param name="content">incident binary content</param>
        /// <returns>Local file name that contains saved binary</returns>
        /// 
        private String saveFile(long incidentId,
                              String fileName,
                              byte[] content)
        {
            String fName = null;
            BinaryWriter binOut = null;
            try
            {
                if (content != null)
                {
                    fName = Path.GetFileName(fileName);
                    fName = incidentId + "_" + fName;
                    fName = Path.Combine(Directory.GetCurrentDirectory(), fName);

                    if (File.Exists(fName))
                    {
                        File.Delete(fName);
                    }
                    FileStream fileOut = new FileStream(fName, FileMode.Create);
                    binOut = new BinaryWriter(fileOut);
                    binOut.Write(content);

                    //fName = Path.GetFileName(fName);
                    Console.WriteLine("Downloaded filenanme - " + fName);
                }
            }
            catch (Exception exp)
            {
                throw (exp);
            }
            finally
            {
                if (binOut != null)
                {
                    binOut.Close();
                }
            }
            return fName;
        }
    }
}
