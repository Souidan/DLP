//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.ServiceModel;
using System.ServiceModel.Channels;
using Client;
using ReportingAPISample.src.List;
using ReportingAPISample.src;
using ReportingAPISample.src.Violations;

namespace UpdateAPISample
{
    class Program
    {
        ///
        /// <summary>
        /// Command line application to read report and individual incident data
        /// via web service. Argument syntax is NAME=VALUE.
        ///
        /// ------------------------------------------------------
        /// Arguments to specify web service connectivity
        /// and authenticate requests:
        ///
        /// URL=...      - HTTPS URL to access incident update/reporting web service WSDL
        /// USER=...     - Enforce user name to authenticate web service requests
        /// PASSWORD=... - Enforce user password
        ///
        /// ------------------------------------------------------
        /// Arguments to read incident list report. Authenticated user should be
        /// the one who saved report or have Enforce permissions to read report.
        ///
        /// REPORT_ID=...       - saved and shared incident list report ID
        /// DATE_LATER_THAN=... - date to retrieve reported incidents created after this date
        ///
        /// ------------------------------------------------------
        /// Arguments to read individual incident details. Support network SMTP
        /// and discover file system incidents:
        ///
        /// INCIDENT_ID=...     - incident id
        /// GET_HISTORY=True    - to retrieve incident history with details, optional
        /// GET_VIOLATIONS=True - to retrieve policy rule violations with details, optional
        /// GET_IMAGE_VIOLATIONS=True - to retrieve image violations with details, optional. 
        /// When setting this parameter to true, make sure to set even GET_VIOLATIONS to true. 
        /// Otherwise no image violations are returned
        /// 
        ///
        /// ------------------------------------------------------
        /// Arguments to read individual incident original message
        /// and binary attachments
        /// 
        /// INCIDENT_ID=...            - incident id
        /// GET_ALL_COMPONENTS=True    - to retrieve binaries for all incident attachments, optional, default 'false'
        /// GET_ORIGINAL_MESSAGE=True  - to retrieve incident original message binary, optional, default 'false'
        /// COMPONENT_ID=...           - incident binary component ID. Optional, applicable when
        ///                              GET_ALL_COMPONENTS=False or skipped
        /// 
        /// Component ID is optional. It helps to request the only one binary
        /// attachment for specified incident. 
        /// Use two step process:
        ///     1. Request GET_ALL_COMPONENTS=True and read all binary component metadata including ID
        ///     2. Identify component and use component ID to retrieve binary
        /// 
        /// 
        /// </summary>
        /// <param name="args">application command line arguments</param>
        ///
        static void Main(string[] args)
        {
            ReportingServiceClient client = null;
            int errorCode = 0;
            try
            {
                Dictionary<String, String> arguments = parseArguments(args);
                client = new ReportingServiceClient(arguments["URL"],
                                                    arguments["USER"],
                                                    arguments["PASSWORD"]);
                client.connect();

                // Submit request to incident reporting
                // web service method
                //
                ServiceCall[] handlers = { new IncidentList(),
                                           new IncidentBinaries(),
                                           new IncidentViolations(),
                                           new IncidentDetails()                                   
                                           };
                foreach(ServiceCall handler in handlers)
                {
                    if (handler.isRequested(arguments))
                    {
                        handler.submit(client, arguments);
                        break;
                    }
                }
            }
            catch (Exception exp)
            {
                Console.WriteLine(getErrorMessage(exp));
                Console.WriteLine(exp.ToString());
                Console.WriteLine(exp.StackTrace);
                errorCode = -1;
            }
            finally
            {
                // Disconnect web service client.
                // Return command line operation code.
                //
                if (client != null)
                {
                    client.disconnect();
                }
                //Environment.Exit(errorCode);
            }
        }


        ///
        /// <summary>
        /// Parse arguments from command line. Arguments specified
        /// in format: name=value
        /// </summary>
        ///
        /// <param name="args">application command line arguments</param>
        /// <returns>parsed arguments name/value</returns>
        ///
        private static Dictionary<String, String> parseArguments(string[] args)
        {
            Dictionary<String, String> arguments = new Dictionary<String, String>();
            if (args.Length == 0)
            {
                throw new NotImplementedException("At leats one argument is missing");
            }
            else
            {
                foreach (string arg in args)
                {
                    int sep_index = arg.IndexOf("=");
                    if (sep_index >= 0)
                    {
                        arguments.Add(arg.Substring(0, sep_index), arg.Substring(sep_index + 1));
                    }
                }
            }
            return arguments;
        }


        ///
        /// <summary>
        /// Return exception type, exception error message
        /// and details in one string
        /// </summary>
        ///
        /// <param name="exp">client proxy exception</param>
        /// <returns>error string that includes exception class name, message and details</returns>
        ///
        private static String getErrorMessage(Exception exp)
        {
            String message = exp.Message;
            String details = getErrorDetails(exp);

            StringBuilder errorMessage = new StringBuilder();
            errorMessage.Append(exp.GetType().Name);
            if (message != null)
            {
                errorMessage.Append(": ");
                errorMessage.Append(message);
            }
            if (details != null && !details.Equals(message))
            {
                errorMessage.Append(". Details: ");
                errorMessage.Append(details);
            }

            return errorMessage.ToString();
        }


        ///
        /// <summary>
        /// Extract web service error details message
        /// </summary>
        ///
        /// <param name="exp">client proxy exception</param>
        /// <returns>web service error details, if specified</returns>
        ///
        private static String getErrorDetails(Exception exp)
        {
            String details = "";
            if (exp is FaultException)
            {
                MessageFault messageFault = ((FaultException)exp).CreateMessageFault();
                if (messageFault.HasDetail == true)
                {
                    System.Xml.XmlElement xmlDetails = messageFault.GetDetail<System.Xml.XmlElement>();
                    if (xmlDetails.HasChildNodes)
                    {
                        details = xmlDetails.FirstChild.InnerText;
                    }
                }
            }
            if (details == null)
            {
                details = "null";
            }

            return details;
        }
    }
}
