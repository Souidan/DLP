﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReportingAPISample.src.Details
{
    public class GeneralDetailsHandler
    {
        /// 
        /// <summary>
        /// Read incident generic details
        /// </summary>
        /// <param name="incidentDetails">incident details</param>
        /// 
        public void readGeneralDetails(IncidentDetailType incidentDetails)
        {
            print("General details");
            print("ID", incidentDetails.incidentLongId);
            print("Detection date", incidentDetails.detectionDate, incidentDetails.detectionDateSpecified);
            print("Creation date", incidentDetails.incidentCreationDate, incidentDetails.incidentCreationDateSpecified);
            print("Detection server", incidentDetails.detectionServer);
            print("Status", incidentDetails.status.Value);
            print("Severity", incidentDetails.severity.Value);
            print("Blocked status", incidentDetails.blockedStatus.Value);
            print("Data owner", (incidentDetails.dataOwner == null ? "" : incidentDetails.dataOwner.name));
            print("Message type", incidentDetails.messageType.Value);
            print("Source type", incidentDetails.messageSource.sourceType);
            print("Source", incidentDetails.messageSource.Value);
            print("Policy", incidentDetails.policy.name);
            print("Policy id", incidentDetails.policy.policyId, incidentDetails.policy.policyIdSpecified);
            print("Policy version", incidentDetails.policy.version);
            print("Number violated rules", incidentDetails.ruleViolationCount, incidentDetails.ruleViolationCountSpecified);


            // Print other violated policies
            //
            if (incidentDetails.otherViolatedPolicy != null)
            {
                foreach (PolicyType policy in incidentDetails.otherViolatedPolicy)
                {
                    print("Other policy", policy.name);
                    print("Other policy id", policy.policyId, incidentDetails.policy.policyIdSpecified);
                    print("Other policy version", policy.version);
                }
            }

            // Print violated policy rules
            //
            foreach (PolicyRuleType rule in incidentDetails.violatedPolicyRule)
            {
                print("Violated policy rule", rule.ruleName);
            }

            // Print custom attributes specified
            // for incident
            //
            if (incidentDetails.customAttributeGroup != null)
            {
                foreach (CustomAttributeGroupType attrGroup in incidentDetails.customAttributeGroup)
                {
                    print("Custom attribute group name", attrGroup.name);
                    foreach (CustomAttributeType customAttribute in attrGroup.customAttribute)
                    {
                        print("Custom attribute", customAttribute.name + "=" + customAttribute.value);
                    }
                }
            }
        }


        /// 
        /// <summary>
        /// Print attributes header
        /// </summary>
        /// <param name="header">header string</param>
        /// 
        public void print(String header)
        {
            Console.WriteLine("   " + header);
            Console.WriteLine("   -------------------------");
        }


        /// 
        /// <summary>
        /// Print incident detail attribute
        /// </summary>
        /// <param name="attrName">attribute name</param>
        /// <param name="attrValue">attribute value</param>
        /// 
        public void print(String attrName,
                          Object attrValue)
        {

            Console.WriteLine("   " + attrName + "=" + (attrValue == null ? "" : attrValue.ToString()));
        }


        /// 
        /// <summary>
        /// Print incident detail attribute. Condition attribute notifies
        /// when meaningful value is specified in response
        /// </summary>
        /// <param name="attrName">attribute name</param>
        /// <param name="attrValue">attribute value</param>
        /// <param name="is_in_response">True when response contains original attribute value</param>
        /// 
        public void print(String attrName,
                          Object attrValue,
                          bool is_in_response)
        {
            if (is_in_response)
            {
                Console.WriteLine("   " + attrName + "=" + (attrValue == null ? "" : attrValue.ToString()));
            }
        }
    }
}
