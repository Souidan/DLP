﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReportingAPISample.src.Details
{
    class FileSystemDiscoverDetailsHandler : DiscoverDetailsHandler, 
                                             IncidentDetailsHandler
    {
        /// 
        /// <summary>
        /// Check if incident details belong to file system 
        /// discover incident
        /// </summary>
        /// <param name="incidentDetails">incident details</param>
        /// <returns>True when details belong to file system discover incident</returns>
        /// 
        public bool isIncidentType(IncidentDetailType incidentDetails)
        {
            return (incidentDetails is DiscoverFileSystemIncidentDetail);
        }


        /// 
        /// <summary>
        /// Handle discover file system incident details
        /// </summary>
        /// <param name="incidentDetails">incident details</param>
        /// 
        public void readDetails(IncidentDetailType incidentDetails)
        {
            base.readDiscoverDetails(incidentDetails);
            DiscoverFileSystemIncidentDetail fsDetails = (DiscoverFileSystemIncidentDetail)incidentDetails;

            // Print file details
            //
            print("File system details");
            print("File name", fsDetails.fileName);
            print("File path", fsDetails.filePath);
            print("File owner", fsDetails.fileOwner);
            print("File created", fsDetails.fileCreateDate, fsDetails.fileCreateDateSpecified);
            print("File last modified", fsDetails.fileLastModifiedDate, fsDetails.fileLastModifiedDateSpecified);
            print("File last accessed", fsDetails.fileLastAccessDate, fsDetails.fileLastAccessDateSpecified);
            print("Remediation location", fsDetails.remediationLocation);

            // Print file ACL details
            //
            foreach(ACLType aclEntry in fsDetails.fileACL)
            {
                print("File ACL", aclEntry.permission.Value + " " + 
                                  aclEntry.grantOrDeny.Value + " " + 
                                  aclEntry.principal);
            }

            // Print file document and violated content
            // details
            //

            if (fsDetails.file != null)
            {
                foreach (MessageComponentType file in fsDetails.file)
                {
                    print("File document name", file.name);
                    print("File document type", file.componentType);
                    print("File document format", file.documentFormat);
                    print("File number violated rules", file.ruleViolationCount, file.ruleViolationCountSpecified);

                    foreach (PolicyRuleViolationType violatedRule in file.policyRuleViolation)
                    {
                        print("File violated policy rule", violatedRule.policyRule);
                        foreach (ViolationType violation in violatedRule.violation)
                        {
                            print("File violated content", violation.Item.ToString());
                            if (violation.Item is ImageViolationType)
                            {
                                ImageViolationType imageViolation = (ImageViolationType) violation.Item;
                                print("Confidence", imageViolation.confidence);
                                print("Filling Score", imageViolation.fillScore);
                                print("Profile", imageViolation.profileName);

                            }
                        }
                    }
                }


            }
        }
    }
}
