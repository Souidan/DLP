﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client;
using ReportingAPISample.src.Details;
using ReportingAPISample.src.Details.IncidentType.Network;

namespace ReportingAPISample.src.List
{
    public class IncidentDetails : ServiceCall
    {
        private static List<IncidentDetailsHandler> detailHandlers = new List<IncidentDetailsHandler>();

        /// 
        /// <summary>
        /// Initialize incident detail handlers
        /// </summary>
        /// 
        static IncidentDetails()
        {
            detailHandlers.Add(new FileSystemDiscoverDetailsHandler());
            detailHandlers.Add(new EmailDetailsHandler());
        }


        /// 
        /// <summary>
        /// Check if Enforce incident details
        /// are requested.
        /// 
        /// Supported arguments:
        /// 
        /// INCIDENT_ID=...     - incident id
        /// GET_HISTORY=True    - to retrieve incident history with details, optional
        /// GET_VIOLATIONS=True - to retrieve policy rule violations with details, optional
        /// 
        /// </summary>
        /// <param name="arguments">arguments(INCIDENT_ID and GET_HISTORY, GET_VIOLATIONS)</param>
        /// <returns>True if arguments contain INCIDENT_ID</returns>
        /// 
        public override Boolean isRequested(Dictionary<String, String> arguments)
        {
            return (getArgument(arguments, "INCIDENT_ID") != null);
        }


        /// 
        /// <summary>
        /// Retrieve attributes for specified incident ID.
        /// 
        /// Incident ID is specified in argument 
        /// as INCIDENT_ID
        /// 
        /// 
        /// </summary>
        /// <param name="client">incident reporting web service client</param>
        /// <param name="arguments">optional arguments(the DATE_LATER_THAN)</param>
        /// 
        public override void submit(ReportingServiceClient client,
                                    Dictionary<String, String> arguments)
        {
            // Create web service request.
            // Specify incident ID to retrieve attributes.
            //
            IncidentDetailRequest request = new IncidentDetailRequest();

            List<long> incidentIds = new List<long>();
            foreach (String key in arguments.Keys)
            {
                if (key.StartsWith("INCIDENT_ID"))
                {
                    long incidentId = Convert.ToInt64(getArgument(arguments, key));
                    incidentIds.Add(incidentId);
                }
            }
            request.incidentLongId = incidentIds.ToArray();

            // Notice to get history and violations
            // with incident details
            //
            request.includeHistory = isTrue(arguments, "GET_HISTORY");
            request.includeViolations = isTrue(arguments, "GET_VIOLATIONS");
            request.includeImageViolations = isTrue(arguments, "GET_IMAGE_VIOLATIONS");


            // Submit web service request to retrieve. 
            // Print incident attributes

            //
            IncidentServicePortTypeClient clientPort = client.getPortClient();
            IncidentDetailResult[] responses = clientPort.incidentDetail(request);

            foreach (IncidentDetailResult response in responses)
            {
                Console.WriteLine("Incident details:");
                Console.WriteLine("   Response status=" + response.statusCode);

                IncidentDetailType incidentDetails = response.incident;

                foreach (IncidentDetailsHandler handler in detailHandlers)
                {
                    if (handler.isIncidentType(incidentDetails))
                    {
                        handler.readDetails(incidentDetails);
                        break;
                    }
                }
            }
        }
    }
}
