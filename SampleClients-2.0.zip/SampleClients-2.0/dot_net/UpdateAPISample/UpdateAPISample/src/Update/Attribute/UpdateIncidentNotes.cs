﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client;

namespace UpdateAPISample.src.Update
{
    class UpdateIncidentNotes : UpdateIncidentAttribute
    {
        /// 
        /// <summary>
        /// Matching command line attribute NOTE_TEXT...=...
        /// </summary>
        /// <returns>NOTE_TEXT</returns>
        /// 
        public String argumentName()
        {
            return "NOTE_TEXT";
        }


        /// 
        /// <summary>
        /// Set updating incident note. Specify note
        /// date as of now
        /// </summary>
        /// <param name="attributes">incident atributes to update</param>
        /// <param name="attributeName">NOTE_TEXT..., could be NOTE_TEXT_N where N - number</param>
        /// <param name="noteText">updating incident note text</param>
        /// 
        public void update(IncidentAttributes attributes,
                           String attributeName,
                           String noteText)
        {
            IncidentNote note = new IncidentNote();

            note.note = noteText;
            note.dateAndTime = DateTime.Now;
            note.dateAndTimeSpecified = true;

            List<IncidentNote> notes;
            if (attributes.note != null)
            {
                notes = attributes.note.ToList();
            }
            else
            {
                notes = new List<IncidentNote>();
            }

            notes.Add(note);
            attributes.note = notes.ToArray();
        }
    }
}
