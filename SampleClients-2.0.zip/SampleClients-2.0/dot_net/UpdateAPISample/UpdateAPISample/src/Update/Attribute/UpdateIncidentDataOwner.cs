﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client;

namespace UpdateAPISample.src.Update
{
    class UpdateIncidentDataOwner : UpdateIncidentAttribute
    {
        /// 
        /// <summary>
        /// Matching command line attribute DATA_OWNER_...=...
        /// </summary>
        /// <returns>DATA_OWNER_</returns>
        /// 
        public String argumentName()
        {
            return "DATA_OWNER_";
        }


        /// 
        /// <summary>
        /// Set updating incident data owner name
        /// or email
        /// </summary>
        /// <param name="attributes">incident atributes to update</param>
        /// <param name="attributeName">DATA_OWNER_NAME or DATA_OWNER_EMAIL</param>
        /// <param name="nameOrEmail">updating incident data owner name or email value</param>
        /// 
        public void update(IncidentAttributes attributes,
                           String attributeName,
                           String nameOrEmail)
        {
            // Reuse data owner request data
            // or create new one
            //
            DataOwnerType dataOwner;
            if (attributes.dataOwner != null)  
            {
                dataOwner = attributes.dataOwner;
            }
            else
            {
                dataOwner = new DataOwnerType();
            }

            // Set data owner name 
            // or email
            //
            if (attributeName.EndsWith("NAME"))
            {
                dataOwner.name = nameOrEmail;
            }
            else if (attributeName.EndsWith("EMAIL"))
            {
                dataOwner.email = nameOrEmail;
            }

            // Set data owner to updating
            // incident attributes
            //
            attributes.dataOwner = dataOwner;
        }
    }
}
