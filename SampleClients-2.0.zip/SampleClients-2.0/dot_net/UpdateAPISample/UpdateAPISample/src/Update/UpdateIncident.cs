﻿
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright � 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client;
using ReportingAPISample.src;

namespace UpdateAPISample.src.Update
{
    /// 
    /// <summary>
    /// Process web service request to incident 
    /// update method
    /// </summary>
    /// 
    public class UpdateIncident : ServiceCall
    {
        private static List<UpdateIncidentAttribute> attributeUpdaters = new List<UpdateIncidentAttribute>();

        /// 
        /// <summary>
        /// Static constructor. Create udating incident attribute 
        /// command line argument handlers
        /// </summary>
        /// 
        static UpdateIncident()
        {
            attributeUpdaters.Add(new UpdateIncidentStatus());
            attributeUpdaters.Add(new UpdateIncidentSeverity());
            attributeUpdaters.Add(new UpdateIncidentDataOwner());
            attributeUpdaters.Add(new UpdateIncidentNotes());
            attributeUpdaters.Add(new UpdateIncidentRemediationLocation());
            attributeUpdaters.Add(new UpdateIncidentRemediationStatus());
            attributeUpdaters.Add(new UpdateIncidentCustomAttribute());
        }


        /// 
        /// <summary>
        /// Check if incident update method is requested 
        /// in application command line arguments
        /// </summary>
        /// <param name="arguments">command line arguments</param>
        /// <returns>True if arguments contain specific parameter(s)</returns>
        /// 
        public override Boolean isRequested(Dictionary<String, String> arguments)
        {
            return (getArgument(arguments, "INCIDENT_ID") != null);
        }


        /// 
        /// <summary>
        /// Update incident attribute. Submit batch with 
        /// one incident to update
        /// </summary>
        /// <param name="client">update incident web service client</param>
        /// <param name="arguments">parsed command line arguments name/value</param>
        /// 
        public override void submit(UpdateServiceClient client,
                                    Dictionary<String, String> arguments)
        {
            // Create web service request.
            // Set incident ID in web service request.
            // Collect incident attributes to update
            //
            IncidentUpdateBatch[] requests = { new IncidentUpdateBatch() };
            long[] ids = getIncidentIds(arguments);
            requests[0].incidentLongId = ids;
            requests[0].incidentAttributes = setUpdatingAttributes(arguments);

            // Submit request batch to incident update web service
            // and read result batch.
            //
            IncidentServicePortTypeClient clientPort = client.getPortClient();
            IncidentUpdateBatchResult[] responses = clientPort.updateIncidents(requests);

            foreach (IncidentUpdateBatchResult response in responses)
            {
                Console.WriteLine("Update incident ID = " + getArgument(arguments, "INCIDENT_ID"));
                Console.WriteLine("Response status code = " + response.statusCode);
            }
        }


        /// 
        /// <summary>
        /// Enumerate parsed application command line arguments
        /// and find incident attributes to update.
        /// </summary>
        /// <param name="arguments">command line arguments</param>
        /// <returns>incident attributes to update</returns>
        /// 
        private IncidentAttributes setUpdatingAttributes(Dictionary<String, String> arguments)
        {
            IncidentAttributes attributes = new IncidentAttributes();
            foreach (String key in arguments.Keys)
            {
                foreach (UpdateIncidentAttribute updater in attributeUpdaters)
                {
                    if (key.StartsWith(updater.argumentName()))
                    {
                        updater.update(attributes, key, arguments[key]);
                    }
                }
            }

            return attributes;
        }


        /// 
        /// <summary>
        /// Get all the incident IDs specified in command
        /// line arguments 'INCIDENT_ID' and 'INCIDENT_ID_...'
        /// </summary>
        /// <param name="arguments">application command line arguments</param>
        /// <returns>An array of incident IDs</returns>
        /// 

        private long[] getIncidentIds(Dictionary<String, String> arguments)
        {
            List<long> incidentIds = new List<long>();
            string val = getArgument(arguments, "INCIDENT_ID");
            string[] strIncidentIds = val.Split(',');
            foreach (string incidentId in strIncidentIds)
            {                        
                incidentIds.Add(Convert.ToInt64(incidentId));
            }
            
            return incidentIds.ToArray();
        }
    }
}
