//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Services.Update;

import Client.UpdateServiceClient;
import Services.ServiceCall;
import com.vontu.v2011.enforce.webservice.incident.AuthenticationFailedFault;
import com.vontu.v2011.enforce.webservice.incident.AuthorizationFailedFault;
import com.vontu.v2011.enforce.webservice.incident.IncidentServicePortType;
import com.vontu.v2011.enforce.webservice.incident.common.schema.CustomAttributeType;
import com.vontu.v2011.enforce.webservice.incident.common.schema.DataOwnerType;
import com.vontu.v2011.enforce.webservice.incident.common.schema.IncidentSeverityType;
import com.vontu.v2011.enforce.webservice.incident.common.schema.IncidentStatusType;
import com.vontu.v2011.enforce.webservice.incident.schema.*;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.*;


public class UpdateIncidents extends ServiceCall
{
    /**
     * <summary>
     * Check if incident id or incident longId is provided in arguments
     * </summary>
     * <param name="arguments">command line arguments</param>
     * <returns>True if arguments contain specific parameter(s)</returns>
     */
    public boolean isRequested(Map<String, String> arguments)
    {
        return (arguments.get("INCIDENT_ID") != null || arguments.get("INCIDENT_LONGID") != null);
    }

    /**
     * <summary>
     * Update incident attribute. Submit batch with
     * one incident to update
     * </summary>
     * <param name="client">update incident web service client</param>
     * <param name="arguments">parsed command line arguments name/value</param>
     */
    public void submit(UpdateServiceClient client, Map<String, String> arguments)
    {
        IncidentUpdateRequest request = new IncidentUpdateRequest();
        IncidentUpdateBatch batch = new IncidentUpdateBatch();
        batch.setBatchId("_" + UUID.randomUUID().toString());
        List<IncidentUpdateBatch> actions = request.getUpdateBatch();
        actions.add(batch);

        long id;
        String[] incident_id;
        if(arguments.get("INCIDENT_ID") != null)
        {
        	incident_id = (arguments.get("INCIDENT_ID").toString()).split(",");	
        }
        else
        {
        	throw new IllegalArgumentException("Argument missing, verify the docs for the proper format");
        }
        
        for(String ids : incident_id)
        {
            id = Long.parseLong(ids);
            List<Long> incidentIDs = batch.getIncidentLongId();
            incidentIDs.add(id);
        }

        setUpdatingAttributes(arguments, batch);

        try
        {
            IncidentServicePortType servicePort = client.getPortClient();
            IncidentUpdateResponse response = servicePort.updateIncidents(request);
            System.out.println("The Response Status Code for the request: "+response.getBatchResult().get(0).getStatusCode());
            List<Long> inaccessibleIds = response.getBatchResult().get(0).getInaccessibleIncidentLongId();
            if(inaccessibleIds.size()>0)
            {
                for (Iterator iterator = inaccessibleIds.iterator(); iterator.hasNext(); )
                {
                    System.out.println("The incident is no longer accessible, Incident id: "+iterator.next());
                }

            }
        }
        catch(AuthenticationFailedFault exp)
        {
            System.out.println("Authentication failed for the request. Please verify the credentials you provided");
        }
        catch(AuthorizationFailedFault exp)
        {
            System.out.println("Authorization failed for the request. Please verify the credentials" +
                    " provided have enough permissions to perform the request ");
        }
        catch(Exception exp)
        {
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }

    }

    /**
     * <summary>
     * Parse the arguments and call the appropriate method to update the required type
     * </summary>
     * <param name="arguments">parsed command line arguments name/value</param>
     * <param name="IncidentUpdateBatch">incident update batch</param>
     */
    private static void setUpdatingAttributes(Map<String, String> arguments, IncidentUpdateBatch batch)
    {
        IncidentAttributes attributes =  new IncidentAttributes();
        batch.setIncidentAttributes(attributes);

        for(String updateParam : arguments.keySet())
        {
            if(updateParam.startsWith("STATUS"))
                updateIncidentStatus(attributes, updateParam, arguments.get(updateParam));

            else if(updateParam.startsWith("SEVERITY"))
                updateIncidentSeverity(attributes, updateParam, arguments.get(updateParam));

            else if(updateParam.startsWith("DATA_OWNER_"))
                updateIncidentDataOwner(attributes, updateParam, arguments.get(updateParam));

            else if(updateParam.startsWith("REMEDIATION_STATUS"))
                updateIncidentRemediationStatus(attributes, updateParam, arguments.get(updateParam));

            else if(updateParam.startsWith("REMEDIATION_LOCATION"))
                updateIncidentRemediationLocation(attributes, updateParam, arguments.get(updateParam));

            else if(updateParam.startsWith("NOTE_TEXT"))
                updateIncidentNotes(attributes, updateParam, arguments.get(updateParam));

            else if(updateParam.startsWith("CUSTOM_"))
                updateIncidentCustomAttribute(attributes, updateParam, arguments.get(updateParam));
        } 

    }

    /**
     * <summary>
     * Set the attribute name and values to update
     * </summary>
     * <param name="IncidentAttributes">attributes</param>
     * <param name="attrName">attribute name</param>
     * <param name="Value">attribute value</param>
     */
    private static void updateIncidentStatus(IncidentAttributes attributes, String attrName, String value)
    {
        IncidentStatusType status = new IncidentStatusType();
        status.setValue(value);
        attributes.setStatus(status);
    }

    /**
     * <summary>
     * Set the attribute name and values to update
     * </summary>
     * <param name="IncidentAttributes">attributes</param>
     * <param name="attrName">attribute name</param>
     * <param name="Value">attribute value</param>
     */
    private static void updateIncidentSeverity(IncidentAttributes attributes, String attrName, String value)
    {
        IncidentSeverityType severity = new IncidentSeverityType();
        severity.setValue(value);
        attributes.setSeverity(severity);
    }

    /**
     * <summary>
     * Set the attribute name and values to update
     * </summary>
     * <param name="IncidentAttributes">attributes</param>
     * <param name="attrName">attribute name</param>
     * <param name="Value">attribute value</param>
     */
    private static void updateIncidentDataOwner(IncidentAttributes attributes, String attrName, String value)
    {
        DataOwnerType dataOwner;
        if(attributes.getDataOwner()!=null)
        {
            dataOwner = attributes.getDataOwner();
        }
        else
        {
            dataOwner = new DataOwnerType();
        }
        if(attrName.endsWith("NAME"))
        {
            dataOwner.setName(value);
        }
        if(attrName.endsWith("EMAIL"))
        {
            dataOwner.setEmail(value);
        }
        attributes.setDataOwner(dataOwner);
    }

    /**
     * <summary>
     * Set the attribute name and values to update
     * </summary>
     * <param name="IncidentAttributes">attributes</param>
     * <param name="attrName">attribute name</param>
     * <param name="Value">attribute value</param>
     */
    private static void updateIncidentRemediationStatus(IncidentAttributes attributes, String attrName, String value)
    {
        attributes.setRemediationStatus(value);
    }

    /**
     * <summary>
     * Set the attribute name and values to update
     * </summary>
     * <param name="IncidentAttributes">attributes</param>
     * <param name="attrName">attribute name</param>
     * <param name="Value">attribute value</param>
     */
    private static void updateIncidentRemediationLocation(IncidentAttributes attributes, String attrName, String value)
    {
        attributes.setRemediationLocation(value);
    }

    /**
     * <summary>
     * Set the attribute name and values to update
     * </summary>
     * <param name="IncidentAttributes">attributes</param>
     * <param name="attrName">attribute name</param>
     * <param name="Value">attribute value</param>
     */
    private static void updateIncidentNotes(IncidentAttributes attributes, String attrName, String value)
    {
        IncidentNote note = new IncidentNote();
        note.setNote(value);
        Date date = new Date(System.currentTimeMillis());
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        try
        {
            DatatypeFactory _factory = DatatypeFactory.newInstance();
            XMLGregorianCalendar xmlCalendar = _factory.newXMLGregorianCalendar(calendar);
            note.setDateAndTime(xmlCalendar);
            List<IncidentNote> notes = attributes.getNote();
            notes.add(note);
        }
        catch(DatatypeConfigurationException e)
        {
            e.getMessage();
            e.printStackTrace();
        }
    }

    /**
     * <summary>
     * Set the attribute name and values to update
     * </summary>
     * <param name="IncidentAttributes">attributes</param>
     * <param name="attrName">attribute name</param>
     * <param name="Value">attribute value</param>
     */
    private static void updateIncidentCustomAttribute(IncidentAttributes attributes, String attrName, String value)
    {
        CustomAttributeType attribute = new CustomAttributeType();
        String attributeName = attrName.split("_")[1];
        attribute.setName(attributeName);
        attribute.setValue(value);

        List<CustomAttributeType> customAttributes =  attributes.getCustomAttribute();
        customAttributes.add(attribute);
    }

}
