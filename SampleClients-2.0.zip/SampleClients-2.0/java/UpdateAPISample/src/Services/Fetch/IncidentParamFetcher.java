//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Services.Fetch;

import Client.UpdateServiceClient;
import Services.ServiceCall;
import com.vontu.v2011.enforce.webservice.incident.IncidentServicePortType;
import com.vontu.v2011.enforce.webservice.incident.schema.CustomAttributeList;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentStatusList;

import java.util.List;
import java.util.Map;


public class IncidentParamFetcher extends ServiceCall
{
    /**
     *  <summary>
     * Check if incident parameters fetch method is requested
     * in application command line arguments
     * </summary>
     * <param name="arguments">command line arguments</param>
     *
     */
    public boolean isRequested(Map<String, String> arguments)
    {
        return arguments.get("FETCH_PARAM")!=null;
    }

   /**
     * <summary>
     * Fetch incident static parameters(custom attribute names and statuses)
     * exist in Enforce database
     * </summary>
     * <param name="client">update incident web service client</param>
     * <param name="arguments">parsed command line arguments name/value</param>
     */
    public void submit(UpdateServiceClient client, Map<String, String> arguments)
    {
        try
        {
            String paramType = arguments.get("FETCH_PARAM");
            IncidentServicePortType servicePort = client.getPortClient();
            if(paramType.equalsIgnoreCase("CUSTOM_ATTRIBUTES"))
            {
                CustomAttributeList listParams = servicePort.listCustomAttributes();
                printResponse(paramType, listParams.getCustomAttributeName());
            }
            else if(paramType.equalsIgnoreCase("INCIDENT_STATUSES"))
            {
                IncidentStatusList listStatus = servicePort.listIncidentStatus();
                printResponse(paramType, listStatus.getIncidentStatusName());
            }
            else
            {
                System.out.println("Requested attribute not supported " + paramType);
            }

        }
        catch(Exception exp)
        {
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }

    }

   /**
     * <summary>
     * Print incident attribute static values(custom attribute names or statuses)
     * fetched from Enforce database. Shows empty list when no values found
     * in database
     * </summary>
     * <param name="paramType">parameter type: custom attribute names or statuses</param>
     * <param name="listParams">list of parameter values</param>
     */
    private void printResponse(String paramType, List<String> listParams)
    {
        StringBuffer response = new StringBuffer();
        
        for(int i = 0; i < listParams.size(); i++)
        {
            if(response.length()>0)
                response.append(", ");
            response.append(listParams.get(i));
        }
        System.out.println("Comma separated list of " +paramType +" = "+response.toString());

    }

}
