//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
import Client.UpdateServiceClient;
import Services.Fetch.IncidentParamFetcher;
import Services.ServiceCall;
import Services.Update.UpdateIncidents;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 *
 * <summary>
 * Command line application to update incident via web service.
 * Argument syntax is NAME=VALUE.
 *
 * --------------------------------------------------
 * Arguments to specify web service connectivity:
 *
 * URL=...
 * USER=...
 * PASSWORD=...
 *
 * --------------------------------------------------
 * Arguments to specify updating incident and
 * updating attributes:
 *
 *     INCIDENT_ID=...
 *     STATUS=...
 *     SEVERITY=...
 *     REMEDIATION_LOCATION=...
 *     REMEDIATION_STATUS=...
 *     NOTE_TEXT=...
 *     NOTE_TEXT_1=...
 *     NOTE_TEXT_2=...
 *     DATA_OWNER_NAME=...
 *     DATA_OWNER_EMAIL=...
 *     CUSTOM_attribute name=...
 *     INCIDENT_LONGID=...
 *
 *  --------------------------------------------------
 * Arguments to retrieve list of custom attribute names
 * from Enforce database
 *
 *     FETCH_PARAM=CUSTOM_ATTRIBUTES
 *
 * --------------------------------------------------
 * Arguments to retrieve list of incident possible status values
 * from Enforce database:
 *
 *     FETCH_PARAM=INCIDENT_STATUSES
 *
 * </summary>
 * <param name="args">application command line arguments</param>
 * </summary>
 *
 */
public class Program
{
    public static void main(String[] args)
    {
        UpdateServiceClient client;

        try
        {
            Map<String, String> arguments = parseArguments(args);
            client = new UpdateServiceClient(arguments.get("URL"), arguments.get("USER"), arguments.get("PASSWORD"));
            client.connect();

            List<ServiceCall> handlers = new ArrayList<ServiceCall>();
            handlers.add(new UpdateIncidents());
            handlers.add(new IncidentParamFetcher());

           for(ServiceCall handler : handlers)
           {
               if(handler.isRequested(arguments))
               {
                   handler.submit(client, arguments);
                   break;
               }
           }

        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }

    }

  /**
    * <summary>
    * Parse arguments from command line. Arguments specified
    * in format: name=value
    * </summary>
    * <param name="args">application command line arguments</param>
    * <returns>parsed arguments name/value</returns>
    */
    private static Map<String, String> parseArguments(String[] args)
    {
        Map<String, String> arguments = new HashMap();
        if(args.length==0)
        {
            throw new IllegalArgumentException("No arguments are passed or missing");
        }
        else
        {
            for(String arg : args)
            {
                String[] valuePair = arg.split("=");
                if(valuePair.length==2)
                {
                    arguments.put(valuePair[0], valuePair[1]);
                }
                else throw new IllegalArgumentException("The arguments are not properly formatted, verify the docs for the proper format");
            }

        }

        return arguments;
    }
}
