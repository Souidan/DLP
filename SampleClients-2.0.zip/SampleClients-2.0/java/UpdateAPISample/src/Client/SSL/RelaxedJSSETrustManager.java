//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Client.SSL;

import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;
import java.security.cert.CertificateException;


/**
 * This class provides NULL-certificate manager
 * for public SSL API
 *
 */
public class RelaxedJSSETrustManager
					implements X509TrustManager
{
	/**
	 * Always trust client authentication disregarding
	 * certificate credentials
	 *
	 * @param certs - certificates
	 *
	 */
	public void checkClientTrusted(X509Certificate[] certs,
	                               String s)
										throws CertificateException
	{
		// No exceptions
	}


	/**
	 * Always trust server authentication disregarding
	 * certificate cridentials
	 *
	 * @param certs - certificates
	 *
	 */
	public void checkServerTrusted(X509Certificate[] certs,
	                               String s)
										throws CertificateException
	{
		// No exceptions
	}

	
	/**
	 * Does not reject any certificates. Return nothing
	 *
	 * @return - <code>null</code>
	 *
	 */
	public X509Certificate[] getAcceptedIssuers()
	{
		return null;
	}
}