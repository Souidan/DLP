//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Client;


import com.vontu.v2011.enforce.webservice.incident.IncidentServicePortType;
import com.vontu.v2011.enforce.webservice.incident.IncidentService;
import Client.SSL.JSSESSLBypass;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import java.net.URL;

public class UpdateServiceClient
{
    private String url;
    private String username;
    private String password;
    private IncidentServicePortType servicePort;
    static
	{
	   /**
		 * Eliminates SSL certificate parameters verification. Can implement
		 * the methods in package SSL to adjust SSL certificate verification
		 */
		JSSESSLBypass.relaxSSL();
	}

    /**
     * initializes the client with the given parameters
     * @param url     - url from command line arguments
     * @param username - username from command line arguments
     * @param password - password from command line arguments
     */
    public UpdateServiceClient(String url, String username,String password)
    {
        this.url = url;
        this.username = username;
        this.password = password;
    }


    public void connect()
    {

           try
           {
               servicePort = createServicePort(this.url);
               servicePort = configureAuthentication(servicePort, this.username, this.password);

           }
           catch(Exception exp)
           {
               exp.getMessage();
               exp.printStackTrace();
           }
    }

    /**
     * Get the instance of the IncidentServicePortType
     * @return - the instance of IncidentServicePortType
     * @throws Exception -  in case of error
     */
    public IncidentServicePortType getPortClient() throws Exception
    {
       if (servicePort == null)
       {
           throw new Exception("Port client not connected to reporting API web service");
       }      
       return servicePort;
    }


    /**
     * Create an instance for IncidentServicePortType
     * @param wsdlLocation - wsdlLocation
     * @return IncidentServicePortType - the IncidentServicePortType instance
     * @throws Exception -  in case of error
     */
    public IncidentServicePortType createServicePort(String wsdlLocation)
												throws Exception
	{
		String serviceNamespace = "http://www.vontu.com/v2011/enforce/webservice/incident";
		QName serviceQName = new QName(serviceNamespace,"IncidentService");

		URL serviceWsdlUrl = fixServiceWsdlUrl(wsdlLocation);
		IncidentService webService = new IncidentService(serviceWsdlUrl, serviceQName);
		IncidentServicePortType servicePort = webService.getIncidentServicePortType();
		return servicePort;
	}

    /**
     *  The method will append the required strings if required to
     *  make the given url valid
     * @param wsdlLocation - wsdlLocation
     * @return URL - the fixed url
     * @throws Exception -  in case of error
     */
    private URL fixServiceWsdlUrl(String wsdlLocation)
												throws Exception
	{
		URL serviceUrl;
		if(wsdlLocation.toLowerCase().startsWith("https://"))
		{
			serviceUrl = new URL(wsdlLocation);
		}
		else
		{
			serviceUrl = new URL("https", wsdlLocation, -1, "/ProtectManager/services/v2011/incidents?wsdl");
		}
		return serviceUrl;
	}

    /**
     * The method binds the given arguments to the binding provider
     * @param servicePort - instance of IncidentServicePortType
     * @param username - username from command line argements
     * @param password - username from command line argements
     * @param <T>  -
     * @return - the instance is returned after binding the given parameters
     */
    private static <T> T configureAuthentication(T servicePort,
	                                             String username,
	                                             String password)
	{
		BindingProvider bindingProvider = (BindingProvider) servicePort;
		bindingProvider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, username);
		bindingProvider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, password);

		return servicePort;
	}

}



