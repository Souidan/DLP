//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Client.SSL;


import javax.net.ssl.*;


/**
 * Bypass SSL certificate verification for JSSE
 */
public class JSSESSLBypass
{
	/**
	 * Replace default SSL certificate trust manager and host verifier
	 * by always trust and no host verification.
	 *
	 * Does not throw an exception but prints it to System.out because
	 * may be invoked from static initialization blocks
	 *
	 *
	 */
	public static void relaxSSL()
	{
		try
		{
			TrustManager[] trustAllCertsManager = new TrustManager[1];
			trustAllCertsManager[0] = new RelaxedJSSETrustManager();

			HostnameVerifier noHostVerifier = new RelaxedJSSEHostVerifier();
			SSLContext sslContext = SSLContext.getInstance("TLS");

			sslContext.init(null, trustAllCertsManager, null);
			HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier(noHostVerifier);
		}
		catch(Throwable exp)
		{
            exp.getMessage();
            exp.printStackTrace();
		}
	}
}