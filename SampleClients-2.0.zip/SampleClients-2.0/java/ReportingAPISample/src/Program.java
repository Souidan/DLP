//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
import Client.ReportingServiceClient;
import Services.ServiceCall;
import Services.Binaries.IncidentBinaries;
import Services.Details.IncidentDetails;
import Services.List.IncidentList;
import Services.violations.IncidentViolations;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * <summary>
 * Command line application to read report and individual incident data
 * via web service. Argument syntax is NAME=VALUE.
 *
 * ------------------------------------------------------
 * Arguments to specify web service connectivity
 * and authenticate requests:
 *
 * URL=...      - HTTPS URL to access incident update/reporting web service WSDL
 * USER=...     - Enforce user name to authenticate web service requests
 * PASSWORD=... - Enforce user password
 *
 * ------------------------------------------------------
 * Arguments to read incident list report. Authenticated user should be
 * the one who saved report or have Enforce permissions to read report.
 *
 * REPORT_ID=...       - saved and shared incident list report ID
 * DATE_LATER_THAN=... - date to retrieve reported incidents created after this date
 *
 * ------------------------------------------------------
 * Arguments to read individual incident details. Support network SMTP
 * and discover file system incidents:
 *
 * INCIDENT_ID=...     - incident id
 * GET_HISTORY=True    - to retrieve incident history with details, optional
 * GET_VIOLATIONS=True - to retrieve policy rule violations with details, optional
 * GET_IMAGE_VIOLATIONS=True - to retrieve image violations with details, optional. 
 * When setting this parameter to true, make sure to set even GET_VIOLATIONS to true. 
 * Otherwise no image violations are returned
 *
 * ------------------------------------------------------
 * Arguments to read individual incident original message
 * and binary attachments
 *
 * GET_ALL_COMPONENTS=True    - to retrieve binaries for all incident attachments, optional
 * GET_ORIGINAL_MESSAGE=True  - to retrieve incident original message binary, optional
 * COMPONENT_ID=...           - incident binary component ID. Optional, applicable when
 *                              GET_ALL_COMPONENTS=False or skipped
 *
 * </summary>
 * <param name="args">application command line arguments</param>
 *
 */
public class Program
{
    public static void main(String[] args)
    {
        ReportingServiceClient client;
        try
        {
            Map<String, String> arguments = parseArguments(args);
            client = new ReportingServiceClient(arguments.get("URL"), arguments.get("USER"), arguments.get("PASSWORD"));
            client.connect();
            List<ServiceCall> handlers = new ArrayList<ServiceCall>();
            handlers.add(new IncidentList());
            handlers.add(new IncidentBinaries());
            handlers.add(new IncidentDetails());
            handlers.add(new IncidentViolations());
            for(ServiceCall handler: handlers)
            {
                if(handler.isRequested(arguments))
                {
                    handler.submit(client, arguments);
                    break;
                }
            }

        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }

    }

    /**
     * <summary>
     * Parse arguments from command line. Arguments specified
     * in format: name=value
     * </summary>
     * <param name="args">application command line arguments</param>
     * <returns>parsed arguments name/value</returns>
     */
    private static Map<String, String> parseArguments(String[] args)
    {
        Map<String, String> arguments = new HashMap();
        if(args.length==0)
        {
            throw new IllegalArgumentException("No arguments are passed or missing");
        }
        else
        {
            for(String arg : args)
            {
                String[] valuePair = arg.split("=");
                if(valuePair.length==2)
                {
                    arguments.put(valuePair[0].toUpperCase(),valuePair[1]);
                }
                else throw new IllegalArgumentException("The arguments are not properly formatted, verify the docs for the proper format");
            }

        }

        return arguments;
    }

}
