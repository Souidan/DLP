//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Services.Details.IncidentType;

import com.vontu.v2011.enforce.webservice.incident.schema.IncidentDetailType;
import com.vontu.v2011.enforce.webservice.incident.schema.PolicyType;
import com.vontu.v2011.enforce.webservice.incident.common.schema.PolicyRuleType;
import com.vontu.v2011.enforce.webservice.incident.common.schema.CustomAttributeGroupType;
import com.vontu.v2011.enforce.webservice.incident.common.schema.CustomAttributeType;

public class GeneralDetailsHandler
{
    /**
     * <summary>
     * Read incident generic details
     * </summary>
     * <param name="incidentDetails">incident details</param>
     */
    public void readGeneralDetails(IncidentDetailType detailHandler)
    {
        System.out.println(" General Details for the incident");
        
        System.out.println("Incident ID: "+ detailHandler.getIncidentLongId());
        System.out.println("Detection Date: "+ detailHandler.getDetectionDate().toGregorianCalendar().getTime());
        System.out.println("Creation Date: "+ detailHandler.getIncidentCreationDate().toGregorianCalendar().getTime());
        System.out.println("Detection Server: "+detailHandler.getDetectionServer());
        System.out.println("Status: "+ detailHandler.getStatus().getValue());
        System.out.println("Severity: "+ detailHandler.getSeverity().getValue());
        System.out.println("Blocked status: "+ detailHandler.getBlockedStatus().getValue());
        System.out.println("Data owner: "+ (detailHandler.getDataOwner() == null ? "" : detailHandler.getDataOwner().getName()));
        System.out.println("Message type: "+ detailHandler.getMessageType().getValue());
        System.out.println("Source type: "+ detailHandler.getMessageSource().getSourceType());
        System.out.println("Source: "+ detailHandler.getMessageSource().getValue());
        System.out.println("Policy: "+ detailHandler.getPolicy().getName());
        System.out.println("Policy id: "+ detailHandler.getPolicy().getPolicyId());
        System.out.println("Policy version: "+ detailHandler.getPolicy().getVersion());
        System.out.println("Number of violated rules: "+ detailHandler.getRuleViolationCount());

         // Print other violated policies
            //
            if (detailHandler.getOtherViolatedPolicy()!= null)
            {
                for (PolicyType policy : detailHandler.getOtherViolatedPolicy())
                {
                    System.out.println("Other policy: "+ policy.getName());
                    System.out.println("Other policy ID: "+ policy.getPolicyId());
                    System.out.println("Other policy version: "+ policy.getVersion());
                }
            }

            // Print violated policy rules
            //
            for (PolicyRuleType rule : detailHandler.getViolatedPolicyRule())
            {
                System.out.println("Violated policy rule: "+ rule.getRuleName());
                System.out.println("Violated policy rule Id: "+ rule.getRuleId());
            }

            // Print custom attributes specified
            // for incident
            //
            if (detailHandler.getCustomAttributeGroup() != null)
            {
                for(CustomAttributeGroupType attrGroup : detailHandler.getCustomAttributeGroup())
                {
                    System.out.println("Custom attribute group name: "+ attrGroup.getName());
                    for(CustomAttributeType customAttribute : attrGroup.getCustomAttribute())
                    {
                        System.out.println("Custom attribute: "+ customAttribute.getName() + "=" + customAttribute.getValue());
                    }
                }
            }


    }
    
}
