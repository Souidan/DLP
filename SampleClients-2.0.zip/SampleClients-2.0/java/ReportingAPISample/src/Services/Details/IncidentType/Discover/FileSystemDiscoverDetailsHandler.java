//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Services.Details.IncidentType.Discover;

import Services.Details.IncidentType.IncidentDetailsHandler;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentDetailType;
import com.vontu.v2011.enforce.webservice.incident.schema.DiscoverFileSystemIncidentDetail;
import com.vontu.v2011.enforce.webservice.incident.common.schema.ACLType;
import com.vontu.v2011.enforce.webservice.incident.common.schema.MessageComponentType;
import com.vontu.v2011.enforce.webservice.incident.common.schema.PolicyRuleViolationType;
import com.vontu.v2011.enforce.webservice.incident.common.schema.ViolationType;

public class FileSystemDiscoverDetailsHandler extends IncidentDetailsHandler
{
     private DiscoverDetailsHandler dischandler = new DiscoverDetailsHandler();

    /**
      * <summary>
      * Check if incident details belong to file system
      *  discover incident
      * </summary>
      * <param name="incidentDetails">incident details</param>
      * <returns>True when details belong to file system discover incident</returns>
      */
    public  boolean isIncidentType(IncidentDetailType detailHandler)
     {
         DiscoverFileSystemIncidentDetail discoverIncident = new DiscoverFileSystemIncidentDetail();
         return (detailHandler.getClass().isInstance(discoverIncident));
     }


    /**
     * <summary>
     * Handle discover file system incident details
     * </summary>
     * <param name="incidentDetails">incident details</param>
     */
    public void readDetails(IncidentDetailType detailHandler)
    {
        // Print file details
        //
        dischandler.readDetails(detailHandler);
        System.out.println("  File System Details  ");
        DiscoverFileSystemIncidentDetail fsDetails = (DiscoverFileSystemIncidentDetail)detailHandler;
        System.out.println("File Name: "+fsDetails.getFileName());
        System.out.println("File path: "+fsDetails.getFilePath());
        System.out.println("File Owner: "+fsDetails.getFileOwner());
        System.out.println("File Created: "+fsDetails.getFileCreateDate());
        System.out.println("File last modified: "+fsDetails.getFileLastModifiedDate());
        System.out.println("File last accessed: "+fsDetails.getFileLastAccessDate());
        System.out.println("Remediation Location: "+fsDetails.getRemediationLocation());
        System.out.println("Remediation Count: "+fsDetails.getRuleViolationCount());

        // Print file ACL details
        //
        for(ACLType aclEntry : fsDetails.getFileACL())
        {
            System.out.println(" File ACL ");
            System.out.println(" File Permission Value:"+ aclEntry.getPermission().getValue());
            System.out.println(" File GrantorDeny Value:"+ aclEntry.getGrantOrDeny().getValue());
            System.out.println(" File GrantorDeny Value:"+ aclEntry.getGrantOrDeny().getValue());
            System.out.println("Principal: "+ aclEntry.getPrincipal());
        }

        // Print file document and violated content
        // details
        //
        printViolations(fsDetails.getFile());
          

    }
    
}
