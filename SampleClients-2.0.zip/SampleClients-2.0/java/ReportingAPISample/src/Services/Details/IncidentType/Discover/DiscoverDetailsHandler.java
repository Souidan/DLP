//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Services.Details.IncidentType.Discover;

import Services.Details.IncidentType.GeneralDetailsHandler;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentDetailType;
import com.vontu.v2011.enforce.webservice.incident.schema.DiscoverIncidentDetailType;

public class DiscoverDetailsHandler extends GeneralDetailsHandler
{
    /**
     * <summary>
     * Handle discover incident details
     * </summary>
     * <param name="incidentDetails">incident details</param>
     */
    public void readDetails(IncidentDetailType detailHandler)
    {
        super.readGeneralDetails(detailHandler);
        DiscoverIncidentDetailType disDetails = (DiscoverIncidentDetailType)detailHandler;
        System.out.println("    Discover Details  ");
        System.out.println("URL: "+disDetails.getURL());
        System.out.println("Superseded: "+disDetails.getSuperseded());
        System.out.println("Seen Before: "+disDetails.getSeenBefore());
        System.out.print("Scan: "+disDetails.getScan().getValue());

    }
}
