//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Services.Details;

import Client.ReportingServiceClient;
import Services.ServiceCall;
import Services.Details.IncidentType.IncidentDetailsHandler;
import Services.Details.IncidentType.Discover.FileSystemDiscoverDetailsHandler;
import Services.Details.IncidentType.Network.EmailsDetailHandler;
import com.vontu.v2011.enforce.webservice.incident.IncidentServicePortType;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentDetailRequest;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentDetailResponse;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentDetailResult;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentDetailType;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class IncidentDetails extends ServiceCall
{
    private static List<IncidentDetailsHandler> detailHandlers = new ArrayList<IncidentDetailsHandler>();
    
    static
    {
        detailHandlers.add(new FileSystemDiscoverDetailsHandler());
        detailHandlers.add(new EmailsDetailHandler());
    }

    /**
     * <summary>
     * Check if Enforce incident details
     * are requested.
     *
     * Supported arguments:
     *
     * INCIDENT_ID=...     - incident id
     * GET_HISTORY=True    - to retrieve incident history with details, optional default to false
     * GET_VIOLATIONS=True - to retrieve policy rule violations with details, optional default to false
     *
     * </summary>
     * <param name="arguments">arguments(INCIDENT_ID and GET_HISTORY, GET_VIOLATIONS)</param>
     * <returns>True if arguments contain INCIDENT_ID or INCIDENT_LONGID</returns>
     */
    public boolean isRequested(Map<String, String> arguments) {
        return (arguments.get("INCIDENT_ID") != null  && (arguments.get("VIOLATIONS") == null || "false".equalsIgnoreCase(arguments.get("VIOLATIONS"))));
    }

    /**
     * <summary>
     * Retrieve attributes for specified incident ID.
     *
     * Incident ID is specified in argument
     * as INCIDENT_ID
     *
     * </summary>
     * <param name="client">incident reporting web service client</param>
     * <param name="arguments">optional arguments(GET_HISTORY, GET_VIOLATIONS)</param>
     */
    public void submit(ReportingServiceClient client, Map<String, String> arguments)
    {
        IncidentDetailRequest request = new IncidentDetailRequest();
        for(String key : arguments.keySet())
        {
           if(key.startsWith("INCIDENT_ID"))
           {
               request.getIncidentLongId().add(Long.parseLong(arguments.get(key)));
           }
          
        }
        request.setIncludeHistory(isTrue(arguments, "GET_HISTORY"));
        request.setIncludeViolations(isTrue(arguments, "GET_VIOLATIONS"));
        request.setIncludeImageViolations(isTrue(arguments, "GET_IMAGE_VIOLATIONS"));

        

        try
        {
            IncidentServicePortType clientPort = client.getPortClient();
            IncidentDetailResponse response = clientPort.incidentDetail(request);

            for(IncidentDetailResult result: response.getResponse())
            {
                System.out.println("-------------------------------------------------------");
                System.out.println("        Incident details for the incident id: "+ result.getIncidentLongId());
                System.out.println("-------------------------------------------------------\n");
                System.out.println("The Response status code for the request is: "+result.getStatusCode());
                IncidentDetailType incidentDetails = result.getIncident();
                for(IncidentDetailsHandler handler : detailHandlers)
                {
                    if(handler.isIncidentType(incidentDetails))
                    {
                        handler.readDetails(incidentDetails);
                        break;
                    }
                    
                }
            }

        }
        catch(Exception exp)
        {
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }

    }
}
