//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Services;
import Client.ReportingServiceClient;

import java.util.Map;

public abstract class ServiceCall
{
    /**
     * <summary>
     * Check if specific incident reporting API web service specific method
     * is requested in arguments
     * </summary>
     * <param name="arguments">command line arguments</param>
     * <returns>True if arguments contain specific parameter(s)</returns>
     */
    public abstract boolean isRequested(Map<String, String> arguments);

    /**
     * <summary>
     * Proceed request to incident Reporting API web service specific method
     * and handle response
     * </summary>
     * <param name="client">incident reporting web service client</param>
     * <param name="arguments">command line arguments</param>
     */
    public abstract void submit(ReportingServiceClient client, Map<String,String> arguments);

    /**
     * <summary>
     * Check if command line argument is specified
     *
     * </summary>
     * <param name="arguments">command line arguments</param>
     * <param name="argumentName">command line argument name</param>
     * <returns>True if argument value is "true" </returns>
     *
     */
     public boolean isTrue(Map<String, String> arguments,
     String argumentName)
     {
     String boolArgument = arguments.get(argumentName);
     boolean is_true = false;

     if (boolArgument != null)
     {
         is_true = (boolArgument.equalsIgnoreCase("true"));
     }
     return is_true;
     }

    
}
