//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Services.List;

import Services.ServiceCall;
import Client.ReportingServiceClient;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentListRequest;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentListResponse;
import com.vontu.v2011.enforce.webservice.incident.IncidentServicePortType;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.datatype.DatatypeFactory;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;

public class IncidentList extends ServiceCall
{
    /**
     *  <summary>
     * Check if Enforce report incident list
     * is requested
     * </summary>
     * <param name="arguments">arguments(REPORT_ID and optional DATE_LATER_THAN)</param>
     * <returns>True if arguments contain REPORT_ID</returns>
     */
    @Override
    public boolean isRequested(Map<String,String> arguments)
    {
         return arguments.get("REPORT_ID")!=null;
    }

    /**
     * <summary>
     * Retrieve incident IDs for specified saved report ID.
     *
     * Report suppose to be saved by the user who authenticates
     * web service client connection. Saved report is ID specified
     * in argument REPORT_ID
     *
     * Get the only incidents originated after the date
     * specified in argument DATE_LATER_THAN. Return all
     * the incidents if DATE_LATER_THAN not specified
     *
     * </summary>
     * <param name="client">incident reporting web service client</param>
     * <param name="arguments">arguments(REPORT_ID and optional DATE_LATER_THAN)</param>
     */
    @Override
    public void submit(ReportingServiceClient client, Map<String,String> arguments)
    {
        IncidentListRequest request = new IncidentListRequest();
        String reportId = arguments.get("REPORT_ID");
        String laterThan = arguments.get("DATE_LATER_THAN");
        XMLGregorianCalendar setDate =null;
		if(laterThan==null)
		{
			laterThan = "01/01/1000";
		}
        if(laterThan!=null)
        {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
            Date inDate = null;
            try
            {
                inDate = dateFormat.parse(laterThan);
                GregorianCalendar c = new GregorianCalendar();
                c.setTime(inDate);
                setDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
            }
            catch (Exception exp)
            {
                exp.getMessage();
                exp.printStackTrace();
            }
            request.setIncidentCreationDateLaterThan(setDate);
        }
        request.setSavedReportId(Integer.parseInt(reportId));
        try
        {
            IncidentServicePortType clientPort = client.getPortClient();
            IncidentListResponse response=clientPort.incidentList(request);
            List<Long> incidentIds = response.getIncidentLongId();
            for(long incidentid:incidentIds)
            {
                System.out.println("Incident ID: " + incidentid);
            }

        }
        catch(Exception exp)
        {
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }

    }


}
