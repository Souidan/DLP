//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Services.violations;

import com.vontu.v2011.enforce.webservice.incident.schema.ViolatingComponent.ViolatingImageInformation;

import Client.ReportingServiceClient;
import Services.ServiceCall;
import com.vontu.v2011.enforce.webservice.incident.IncidentServicePortType;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentViolation;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentViolationsRequest;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentViolationsResponse;
import com.vontu.v2011.enforce.webservice.incident.schema.TextType;
import com.vontu.v2011.enforce.webservice.incident.schema.ViolatingComponent;
import com.vontu.v2011.enforce.webservice.incident.schema.ViolatingSegment;
import com.vontu.v2011.enforce.webservice.incident.schema.ViolatingSegment.DocumentViolation;
import com.vontu.v2011.enforce.webservice.incident.schema.ViolatingSegment.FileSizeViolation;
import com.vontu.v2011.enforce.webservice.incident.schema.ViolatingSegment.Text;
import java.util.List;
import java.util.Map;

public class IncidentViolations extends ServiceCall
{

    /**
     * Checks if the incident violations are requested as per the arguments passed.
     * 
     * @param arguments
     *            map with INCIDENT_ID & MATCH_HIGHLIGHTS
     * 
     * @return True if arguments contain INCIDENT_ID & MATCH_HIGHLIGHTS is true
     */
    @Override
    public boolean isRequested(Map<String, String> arguments)
    {
        return (arguments.get("INCIDENT_ID") != null && "true".equalsIgnoreCase((arguments.get("VIOLATIONS"))));
    }

    /**
     * Submits incident violation request for the specified incident and gets
     * the incident violation response.
     * 
     * @param client
     *            incident reporting web service client
     * @param arguments
     *            map with INCIDENT_ID
     */
    @Override
    public void submit(ReportingServiceClient client, Map<String, String> arguments)
    {
        IncidentViolationsRequest incidentViolationsRequest = new IncidentViolationsRequest();
        incidentViolationsRequest.setIncludeImageViolations(isTrue(arguments, "GET_IMAGE_VIOLATIONS"));
        for (String key : arguments.keySet())
        {
            if (key.startsWith("INCIDENT_ID"))
            {
                incidentViolationsRequest.getIncidentLongId().add(Long.parseLong(arguments.get(key)));
            }
        }

        try
        {
            IncidentServicePortType clientPort = client.getPortClient();
            IncidentViolationsResponse incidentViolationsResponse =
                clientPort.incidentViolations(incidentViolationsRequest);

            for (IncidentViolation incidentViolation : incidentViolationsResponse.getIncidentViolation())
            {
                System.out.println("---------------------------------------------------------------------");
                System.out.println("        Incident Violations for the incident id: " +
                                   incidentViolation.getIncidentLongId());
                System.out.println("---------------------------------------------------------------------\n");
                System.out.println("The response status code is: " + incidentViolation.getStatusCode());
                printViolatingComponents(incidentViolation.getViolatingComponent());
            }

        }
        catch (Exception exp)
        {
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }

    }

    private void printViolatingComponents(List<ViolatingComponent> violatingComponents)
    {
        for (ViolatingComponent violatingComponent : violatingComponents)
        {
            System.out.println();
            System.out.println("Component Name:" + violatingComponent.getName());
            System.out.println("Component Type:" +
                               violatingComponent.getViolatingComponentType().getValue());
            if (violatingComponent.getDocumentFormat() != null)
            {
                System.out.println("Document Format:" + violatingComponent.getDocumentFormat());
            }
            System.out.println("Violation Count:" + violatingComponent.getViolationCount());
            printViolationSegments(violatingComponent.getViolatingSegment());
            if(violatingComponent.getViolatingImageInformation() != null)
            {
                System.out.println("Printing Image Violations");
                for(ViolatingImageInformation imageViolation : violatingComponent.getViolatingImageInformation())
                {
                    System.out.println("Confidence: " + imageViolation.getConfidence());
                    System.out.println("Filling Score: " + imageViolation.getFillScore());
                    System.out.println("Matched Form Name: " + imageViolation.getGallery());
                    System.out.println("Profile Name: " + imageViolation.getProfileName());
                }
            }
        }
    }

    private void printViolationSegments(List<ViolatingSegment> violatingSegments)
    {
        for (ViolatingSegment violatingSegment : violatingSegments)
        {
            System.out.println();
            DocumentViolation documentViolation = violatingSegment.getDocumentViolation();
            FileSizeViolation fileSizeViolation = violatingSegment.getFileSizeViolation();
            List<Text> texts = violatingSegment.getText();
            if (documentViolation != null)
            {
                printDocumentViolation(documentViolation);
            }
            else if (fileSizeViolation != null)
            {
                printFileSizeViolation(fileSizeViolation);
            }
            else
            {
                printViolation(texts);
            }
        }
    }

    private void printFileSizeViolation(FileSizeViolation fileSizeViolation)
    {
        System.out.println("File Size Violation:" + fileSizeViolation.getViolatingFileSize() + " " +
                           fileSizeViolation.getUnits());
    }

    private void printDocumentViolation(DocumentViolation documentViolation)
    {
        System.out.println("Document Violation:");
        System.out.println("Profile Name:" + documentViolation.getDocumentProfileName());
        System.out.println("Document Path:" + documentViolation.getDocumentPath());
        System.out.println("Match Percentage(%):" + documentViolation.getMatchPercentage());
    }

    private void printViolation(List<Text> texts)
    {
        for (Text text : texts)
        {
            if (TextType.VIOLATION.equals(text.getType()))
            {
                System.out.println("Violating Text:" + text.getValue());
            }
            else
            {
                System.out.println("Non Violating Text:" + text.getValue());
            }
        }
    }

}
