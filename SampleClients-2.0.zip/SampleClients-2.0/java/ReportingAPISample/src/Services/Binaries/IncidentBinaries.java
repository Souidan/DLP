//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header start
//////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015 Symantec Corporation. All rights reserved.
//
// THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF SYMANTEC
// CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
// EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
//
// The Licensed Software and Documentation are deemed to be commercial computer
// software as defined in FAR 12.212 and subject to restricted rights as defined
// in FAR Section 52.227-19 "Commercial Computer Software - Restricted Rights"
// and DFARS 227.7202, "Rights in Commercial Computer Software or Commercial
// Computer Software Documentation", as applicable, and any successor
// regulations.  Any use, modification, reproduction release, performance,
// display or disclosure of the Licensed Software and Documentation by the U.S.
// Government shall be solely in accordance with the terms of this Agreement.
//
//////////////////////////////////////////////////////////////////////////////////
// Symantec copyright header stop
//////////////////////////////////////////////////////////////////////////////////
package Services.Binaries;

import Services.ServiceCall;
import Client.ReportingServiceClient;

import java.util.Map;
import java.io.*;

import com.vontu.v2011.enforce.webservice.incident.schema.IncidentBinariesRequest;
import com.vontu.v2011.enforce.webservice.incident.schema.IncidentBinariesResponse;
import com.vontu.v2011.enforce.webservice.incident.IncidentServicePortType;

public class IncidentBinaries extends ServiceCall
{
    /**
     * <summary>
     * Check if Enforce report incident binaries
     * is requested
     *
     * Supported arguments:
     *
     * INCIDENT_ID=...            - incident id
     * GET_ALL_COMPONENTS=True    - to retrieve binaries for all incident attachments, optional
     * GET_ORIGINAL_MESSAGE=True  - to retrieve incident original message binary, optional
     * COMPONENT_ID=...           - incident attachment ID, applicable when GET_ALL_COMPONENTS=False or skipped
     * INCIDENT_ID=...            - incident id
     *
     * </summary>
     * <param name="arguments">arguments</param>
     * <returns>True if arguments contain INCIDENT_ID or INCIDENT_LONGID</returns>
     */
    public boolean isRequested(Map<String, String> arguments)
    {
        return (arguments.get("INCIDENT_ID") != null && ((arguments.get("GET_ALL_COMPONENTS") != null) ||
                (arguments.get("GET_ORIGINAL_MESSAGE") != null) ||
                (arguments.get("COMPONENT_ID") != null)));
    }


    /**
     * <summary>
     * Retrieve binary attachment and/or main message
     * for specified incident ID.
     *
     * </summary>
     * <param name="client">incident reporting web service client</param>
     * <param name="arguments">arguments(INCIDENT_ID)</param>
     */
    public void submit(ReportingServiceClient client, Map<String, String> arguments)
    {
        IncidentBinariesRequest request = new IncidentBinariesRequest();     
        
        String incidentLongIdVal = arguments.get("INCIDENT_ID");
        
        request.setIncidentLongId(Long.parseLong(incidentLongIdVal));
        request.setIncludeAllComponents(isTrue(arguments, "GET_ALL_COMPONENTS"));
        if(!isTrue(arguments,"GET_ALL_COMPONENTS"))
        {          
            String componentLongIdVal = arguments.get("COMPONENT_ID");
            if(componentLongIdVal != null)
            {
            	request.setComponentLongId(Long.parseLong(componentLongIdVal));	
            }
            else
            {	
            	throw new IllegalArgumentException("Argument missing, verify the docs for the proper format");
            }
        }
        request.setIncludeOriginalMessage(isTrue(arguments, "GET_ORIGINAL_MESSAGE"));
        request.setIncludeAllComponents(isTrue(arguments, "GET_ALL_COMPONENTS"));

        try
        {
            IncidentServicePortType clientPort = client.getPortClient();
            IncidentBinariesResponse response = clientPort.incidentBinaries(request);
            if(response.getComponent()!=null)
            {
                for(IncidentBinariesResponse.Component respComponent : response.getComponent())
                {
                    //downloading all the components including the email body text as an attachment
                    File file = new File(".");
					String downloadedFileName = new File(respComponent.getName()).getName();
                    saveFile(respComponent.getContent().getInputStream(), file.getCanonicalPath()+"\\"+downloadedFileName);
                    System.out.println("Binary component Name: "+respComponent.getName());                    
                    System.out.println("Binary component ID: "+respComponent.getComponentLongId());
                    System.out.println("Binary component Type: "+respComponent.getComponentType());
                    System.out.println("Saved the binary content to file: "+ file.getCanonicalPath()+"\\"+downloadedFileName);
                }
            }
            if(isTrue(arguments, "GET_ORIGINAL_MESSAGE"))
            {
                File file = new File(".");
                saveFile(response.getOriginalMessage().getInputStream(), file.getCanonicalPath()+"\\"+"original_message");
                System.out.println("Saved the orignal message to: "+ file.getCanonicalPath()+"\\"+"original_message");
            }
        }

        catch(Exception exp)
        {
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }

    }

    /**
     *
     * <summary>
     * Save incident binary content to a local file.
     * </summary>
     * <param name="incidentId">incident ID</param>
     * <param name="fileName">incident content file name</param>
     * <param name="content">incident binary content</param>
     * <returns>Local file name that contains saved binary</returns>
     */
    private void saveFile(InputStream stream, String fileName) throws IOException {
        InputStream inputStream= null;
        OutputStream out = null;
        try
        {
            inputStream =  stream;
            out = new FileOutputStream(fileName);

            int buffer_size = adjustBufferSize(0, inputStream);
            byte[] buffer = new byte[buffer_size];
            int n_read = 0;

            while(n_read != -1)
            {
                n_read = inputStream.read(buffer);
                if(n_read > 0)
                {
                    out.write(buffer, 0, n_read);
                    buffer_size = adjustBufferSize(buffer.length, inputStream);
                    if(buffer.length < buffer_size)
                    {
                        buffer = new byte[buffer_size];
                    }
                }
            }
        }
        finally
        {
            if(out!=null)
            {
                out.close();
            }
            if(inputStream!=null)
            {
                inputStream.close();
            }
        }
    }

    private int adjustBufferSize(int curr_buffer_size, InputStream in) throws IOException
	{
		int buffer_size = curr_buffer_size;
		int n_available = in.available();
		if(n_available > (buffer_size + 1024))
		{
			buffer_size = n_available;
		}
		if(buffer_size < 1024)
		{
			buffer_size = 1024;
		}

		return buffer_size;
	}

}
